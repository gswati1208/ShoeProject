package com.shoestore.basepages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public abstract class Basetest {

	public static WebDriver driver;

	public static WebDriver getDriver(String browser) {
		switch (browser) {
		case "Chrome":
			System.setProperty("webdriver.chrome.driver",
					"C:/Users/swathi/Downloads/chromedriver_win32/chromedriver.exe");
			driver = new ChromeDriver();

		case "IE":
			File file = new File("C:/Users/swathi/Downloads/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			DesiredCapabilities capabilities = DesiredCapabilities
					.internetExplorer();
			capabilities
					.setCapability(
							InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
			driver = new InternetExplorerDriver(capabilities);

		case "FireFox":
			System.setProperty("webdriver.firefox.driver", "path");
			driver = new FirefoxDriver();
		}
		return driver;

	}

	public String getData(String name) throws IOException {

		Properties prop = new Properties();
		FileInputStream input = new FileInputStream(getDataPath());
		prop.load(input);
		String value = prop.getProperty(name);
		return value;

	}

	public abstract String getDataPath();

}
