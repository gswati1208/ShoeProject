package com.shoestore.basepages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class BasePage {

	public WebDriver driver;

	public abstract boolean waitForPageLoad();

	public void waitForElement(By locator, WebDriver driver, int timeOutValue)
			throws IllegalArgumentException {
		if (driver == null) {
			throw new IllegalArgumentException("Webdriver cannot be null");
		}
		WebDriverWait wait = new WebDriverWait(driver, timeOutValue);
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}
}
