package com.shoestore.tests;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.shoestore.basepages.Basetest;
import com.shoestore.pages.HomePage;
import com.shoestore.pages.MonthPage;

public class ShoeStore_DisplayDetailsTest extends Basetest {

	String url;
	String browser;
	String month;

	@Before
	public void setUp() throws IOException {

		month = getData("Month");
		url = getData("URL");
		browser = getData("Browser");

		WebDriver driver = getDriver(browser);
		driver.manage().window().maximize();
		driver.get(url);
		driver.get(month);

	}

	@Test
	public void testDisplayDetails() {

		HomePage home = new HomePage(driver);
		assertTrue("Failed to select month", home.selectMonth(month));
		MonthPage month = new MonthPage(driver);
		// assertTrue("Failed to verify Month",month.isMonthTitlePresent(month));
		assertTrue("Failed to verify description", month.isDescriptionPresent());
		assertTrue("Failed to verify price", month.isPriceDisplayed());
		assertTrue("Failed to verify Image", month.isImagePresent());
	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Override
	public String getDataPath() {
		// TODO Auto-generated method stub
		String path = "C:\\Users\\swathi\\Desktop\\example.properties";
		return path;
	}

}
