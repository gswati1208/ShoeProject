package com.shoestore.tests;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.shoestore.basepages.Basetest;
import com.shoestore.pages.HomePage;

public class ShoeStore_EmailConfirmation_Test extends Basetest {

	String url;
	String browser;
	String email;

	@Before
	public void setUp() throws IOException {

		url = getData("URL");
		email = getData("Email");
		browser = getData("Browser");

		WebDriver driver = getDriver(browser);
		driver.manage().window().maximize();
		driver.get(url);
	}

	@Test
	public void testEmailConfirmation() {

		HomePage home = new HomePage(driver);

		assertTrue("Failed to enter email id", home.enterEmailAddress(email));
		assertTrue("Failed to click submit button", home.clickSubmit());
		assertTrue("Confirmation is not displayed",
				home.isConfirmationDisplayed());

	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Override
	public String getDataPath() {
		// TODO Auto-generated method stub
		String path = "C:\\Users\\swathi\\Desktop\\shoeStoreEmail.properties";
		return path;
	}

}
