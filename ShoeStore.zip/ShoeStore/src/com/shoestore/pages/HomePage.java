package com.shoestore.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.shoestore.basepages.BasePage;

public class HomePage extends BasePage {

	private static final By HOME = By.xpath("//a[text()='Home']");;
	private static final By MAILID = By.name("email");
	private static final By SUBMIT = By.id("remind_email_submit");
	private static final By CONFIRMATION_TEXT = By.id("flash");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public boolean clickHome() {
		boolean isClicked = false;
		WebElement element = driver.findElement(HOME);
		element.click();
		isClicked = true;
		return isClicked;
	}

	public boolean selectMonth(String month) {
		boolean isSelected = false;

		List<WebElement> months = driver.findElements(By
				.xpath("//ul[@class='nav navbar-nav']/li"));
		for (int i = 0; i <= months.size(); i++) {
			System.out.println(months.size());
			String monthName = months.get(i).getText();
			if (month.contains(monthName)) {
				driver.findElement(By.xpath("//a[text()='" + month + "']"))
						.click();
				isSelected = true;
				break;
			}
		}

		return isSelected;

	}

	public boolean enterEmailAddress(String emailId) {
		boolean isPresent = false;
		waitForElement(MAILID, driver, 120);
		WebElement email = driver.findElement(MAILID);
		if (email.isDisplayed()) {
			email.sendKeys(emailId);
			isPresent = true;
		}

		return isPresent;

	}

	public boolean clickSubmit() {

		boolean isClicked = false;

		waitForElement(SUBMIT, driver, 120);
		WebElement submit = driver.findElement(SUBMIT);
		submit.click();

		isClicked = true;

		return isClicked;

	}

	public boolean isConfirmationDisplayed() {
		boolean isPresent = false;
		waitForElement(CONFIRMATION_TEXT, driver, 120);
		String actualText = "Thanks! We will notify you of our new shoes at this email:";
		String expectedText = driver.findElement(CONFIRMATION_TEXT).getText();
		System.out.println(expectedText);
		if (expectedText.contains(actualText)) {
			System.out.println("Successfull");
			isPresent = true;
		}
		return isPresent;
	}

	@Override
	public boolean waitForPageLoad() {
		// TODO Auto-generated method stub
		boolean isLoaded = false;
		waitForElement(HOME, driver, 120);
		isLoaded = true;

		return isLoaded;
	}
}
