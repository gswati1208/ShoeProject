package com.shoestore.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.shoestore.basepages.BasePage;

public class MonthPage extends BasePage {
	public WebDriver driver;

	private static final By TITLE = By.className("title']");
	private static final By PRICE = By.cssSelector(".shoe_price");
	private static final By DESCRIPTION = By.cssSelector(".shoe_description");
	private static final By IMAGE = By.cssSelector(".shoe_image");

	public MonthPage(WebDriver driver) {
		this.driver = driver;
	}

	public boolean isMonthTitlePresent(String month) {
		boolean isPresent = false;
		List<WebElement> shoes = driver.findElements(By
				.xpath("//ul[@id='shoe_list']/li"));
		for (int i = 0; i <= shoes.size(); i++) {
			String monthName = driver.findElement(
					By.xpath("//h2[text()='" + month + "'s Shoes']"))
					.toString();
			if (monthName.contains(month)) {
				isPresent = true;
				break;
			}
		}
		return isPresent;
	}

	public boolean isDescriptionPresent() {
		boolean isPresent = false;
		List<WebElement> shoes = driver.findElements(By
				.xpath("//ul[@id='shoe_list']/li"));
		for (int i = 0; i <= shoes.size(); i++) {
			System.out.println(shoes.size());
			WebElement description = shoes.get(i).findElement(DESCRIPTION);
			if (description.isDisplayed()) {
				isPresent = true;
				break;
			}
		}
		return isPresent;

	}

	public boolean isPriceDisplayed() {
		boolean isPresent = false;
		List<WebElement> shoes = driver.findElements(By
				.xpath("//ul[@id='shoe_list']/li"));
		for (int i = 1; i <= shoes.size(); i++) {
			WebElement price = shoes.get(i).findElement(PRICE);
			if (price.isDisplayed()) {
				isPresent = true;
				break;
			}
		}
		return isPresent;

	}

	public boolean isImagePresent() {
		boolean isPresent = false;
		List<WebElement> shoes = driver.findElements(By
				.xpath("//ul[@id='shoe_list']/li"));
		for (int i = 1; i <= shoes.size(); i++) {
			WebElement shoeImage = shoes.get(i).findElement(IMAGE);
			if (shoeImage.isDisplayed()) {
				isPresent = true;
				break;
			}
		}
		return isPresent;
	}

	@Override
	public boolean waitForPageLoad() {
		// TODO Auto-generated method stub
		boolean isLoaded = false;
		waitForElement(TITLE, driver, 120);
		isLoaded = true;

		return isLoaded;
	}

}
